import React from "react";
import Routes from "./routes";
import "./styles.css";

export default function App() {
  return (
    <div>
      <Routes />
    </div>
  );
}
