import AudioPlayer from "react-h5-audio-player";
import "react-h5-audio-player/lib/styles.css";
// import 'react-h5-audio-player/lib/styles.less' Use LESS
// import 'react-h5-audio-player/src/styles.scss' Use SASS
import ReactDOM from "react-dom";

function App() {
  return (
    <div>
      <label for="opcao">Escolha uma opção:</label>
      <br />
      <br />
      <input type="radio" name="opcao" id="um" />
      Opção 1<br />
      <input type="radio" name="opcao" id="dois" />
      Opção 2<br />
      <input type="radio" name="opcao" id="tres" />
      Opção 3<br />
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));

const Player = () => (
  <AudioPlayer
    autoPlay
    src="http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Kangaroo_MusiQue_-_The_Neverwritten_Role_Playing_Game.mp3"
    onPlay={(e) => console.log("onPlay")}
    // other props here
  />
);

export default Player;
