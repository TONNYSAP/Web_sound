import React from "react";
import ReactAudioPlayer from "react-audio-player";
import { render } from "react-dom";

function Audio() {
  render(
    <div id="area-audio">
      <ReactAudioPlayer src="" autoPlay controls />
    </div>
  );
}

export default Audio;
