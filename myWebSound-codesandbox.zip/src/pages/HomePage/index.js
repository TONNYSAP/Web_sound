import React from "react";
//import ReactDom from "react-dom";
import ReactAudioPlayer from "react-audio-player";
import { Link } from "react-router-dom";
import "../../styles.css";
//import "./audio";

function HomePage() {
  function eventClicked() {
    console.log("O link1 foi clicado.");
    var audio = document.getElementById("player");
    audio.src =
      "http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Kangaroo_MusiQue_-_The_Neverwritten_Role_Playing_Game.mp3";
  }
  function eventClicked2() {
    console.log("O link2 foi clicado.");
    var audio2 = document.getElementById("player");
    audio2.src =
      "http://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Sevish_-__nbsp_.mp3";
  }
  return (
    <div id="container">
      <div id="area-menu">
        <h1 id="titulo">WEB SHOW MUSIC</h1>
        <ul id="menu">
          <li className="menu">
            <Link to="#">Home</Link>
          </li>
          <li className="menu">
            <Link to="/sobre">Sobre</Link>
          </li>
          <li className="menu">
            <Link to="/contato">Contato</Link>
          </li>
          <li className="menu">
            <Link to="/teste">Audio</Link>
          </li>
        </ul>
      </div>
      <div id="area-animacao">
        <div id="videos">&nbsp; &nbsp;</div>
        <hr id="divisao" />

        <div id="opcoes">
          <label for="opcao">Escolha uma opção:</label>
          <br />
          <br />
          <div className="fundo">
            <input type="radio" id="um" name="opcao" onClick={eventClicked} />
            <span className="cor">Kangaroo_MusiQue&nbsp;</span>
          </div>

          <hr />
          <div className="fundo">
            <input
              type="radio"
              id="dois"
              name="opcao"
              onClick={eventClicked2}
            />
            <span className="cor">Sevish&nbsp;</span>
          </div>

          <hr />
          <div className="fundo">
            <input type="radio" id="tres" name="opcao" />
            <span className="cor">XTaKeRuX - Cursed As Love&nbsp;</span>
          </div>

          <hr />
        </div>
      </div>

      <div id="area-audio">
        <ReactAudioPlayer id="player" src="" autoPlay controls />
      </div>
    </div>
  );
}

export default HomePage;
