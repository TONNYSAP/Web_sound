import React from "react";
import { Link } from "react-router-dom";
import "../../../src/styles.css";

function Contato() {
  return (
    <div id="container">
      <div id="contato">
        <h3>Contato</h3>
        <ul id="menu">
          <li className="menu">
            <Link to="/index">Home</Link>
          </li>
          <li className="menu">
            <Link to="/sobre">Sobre</Link>
          </li>
          <li className="menu">
            <Link to="#">Contato</Link>
          </li>
        </ul>
        <h3>Cadastro:</h3>
        <form id="formulario" action="/recebe" method="GET">
          <label for="nome">Nome:</label>
          <input type="text" id="nome" name="nome" />
          <br />
          <br />

          <label for="cidade">Cidade:</label>
          <input type="text" id="cidade" name="cidade" />
          <br />
          <br />

          <label for="endereco">Endereço:</label>
          <input type="text" id="endereco" name="endereco" />
          <br />
          <br />

          <label for="fone">Telefone:</label>
          <input type="text" id="fone" name="fone" />
          <br />
          <br />

          <label>Mensagem:</label>
          <br />
          <textarea id="texto" />
          <br />
          <br />

          <button type="submit">Enviar</button>
        </form>
      </div>
    </div>
  );
}

export default Contato;
