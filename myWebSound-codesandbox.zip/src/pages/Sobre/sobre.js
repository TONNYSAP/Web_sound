import React from "react";
import { Link } from "react-router-dom";
import "../../styles.css";

function Sobre() {
  return (
    <div>
      <h3>Sobre</h3>
      <ul>
        <li>
          <Link to="/index">Home</Link>
        </li>
        <li>
          <Link to="#">Sobre</Link>
        </li>
        <li>
          <Link to="/contato">Contato</Link>
        </li>
      </ul>
    </div>
  );
}

export default Sobre;
