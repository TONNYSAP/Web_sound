import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";

import HomePage from "./pages/HomePage";
import Sobre from "./pages/Sobre/sobre";
import Contato from "./pages/Contato/contato";
import Teste from "./pages/Teste/teste";

function Routes() {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/index" exact component={HomePage} />
        <Route path="/sobre" component={Sobre} />
        <Route path="/contato" component={Contato} />
        <Route path="/teste" component={Teste} />
      </Switch>
    </BrowserRouter>
  );
}
export default Routes;
